"""
This init file is not necessary anymore for making a directory a package.
You can still use it to initialize something and make imports simple

for e.g.

in this file here if you do 

from data_preparation import *

Then while importing the data_prep function elsewhere you won't have to write
from data_prep.data_preparation import data_prep

instead you can write,

from data_prep import data_pred

"""
